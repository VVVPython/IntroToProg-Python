'''------------------------- -----
Assignment 5
Developer: Vladimir Vasilev
Version: New
Title: Working with Dictionaries
----------------------------------'''

# Step 1 - Load data from a file

# when the program starts, create ToDo.txt file
# and fill the initial content per the assignment requirements
objFileName = open("/Users/vladimir/Documents/Class/ToDo.txt", "w")
objFileName.write("Task, Priority \nClean House, low\nPay Bills, high")
objFileName.close()

# Read from ToDo.txt file
objFileName = open("/Users/vladimir/Documents/Class/ToDo.txt", "r")
strData = objFileName.readline()
dicRow1 = {(strData.split(",")[0]).strip(): (strData.split(",")[1]).strip()}
# Add the each dictionary "row" to a python list "table"
lstTable = [dicRow1]  # table of dictionaries

# continue with reading other two rows with for loop
for line in objFileName:
    strData = line
    # divide the data into 2 elements
    dicRow = {(strData.split(",")[0]).strip(): (strData.split(",")[1]).strip()}
    lstTable.append(dicRow)  # add the row to the table
objFileName.close()
print(lstTable)  # verification  step

# Step 2 - Display a menu of choices to the user
while(True):
    print("""
    Please select from the following menu of options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)

    strChoice = input("Which option would you like to perform?:  ")
    print("\n")  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip()) == "1":  # Show current data
        print("Here are the current tasks with assigned priority levels\n")
        for row in lstTable:  # Prints the rows of the table
            print(row)
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip()) == "2":  # Add a new item
        strTask = input("Enter a new task to add to the list: ")
        strPriority = input("Assign  priority level: ")
        dicRow = {(strTask.strip()): (strPriority.strip())}  # divide the data into 2 elements
        lstTable.append(dicRow)  # append method to add the data to existing ToDo.txt file
        print(lstTable)   # verification for the user
        continue

    # Step 5 - Remove an item from the list/Table
    elif (strChoice.strip()) == '3':  # Remove an existing item
        strData = input("Which task to delete?: ")
        for row in lstTable:  # for loop to search every row of the list
            if strData in row:
                lstTable.remove(row)  # remove the task and assigned priority
                print("\nTask", strData,  "was deleted")
                print(lstTable)  # verification for the user
                break
        else: # user input not on the list
            print("\nTask", strData, "doesn't exist.")
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice.strip()) == '4':  # Save Data to File
        objFileName = open("/Users/vladimir/Documents/Class/ToDo.txt", "w")  # txt file open
        objFileName.write(str(lstTable))  # Write the new list
        objFileName.close()  # txt file close
        print("The following data was saved to a file:\n\r", lstTable)
        continue

    # Step 7 - Exit program
    elif (strChoice.strip()) == '5':  # Exit program
        print("You have selected to exit.")
        break  # and Exit the program

    else:
        print("Incorrect input. Please try again or enter 5 to exit")
        continue


input("\n\nPress the enter key to terminate this program.")